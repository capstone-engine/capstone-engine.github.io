#!/bin/sh
# this prints out Capstone setup & core+Python-binding versions

python -c "import capstone; print capstone.debug()"
